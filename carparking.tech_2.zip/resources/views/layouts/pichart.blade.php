{!! $chartjs->render() !!}
