#!/bin/sh

cd /home/u823476969/domains/carparking.tech && php artisan schedule:run >> /dev/null 2>&1